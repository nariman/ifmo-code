Loggers can be tested by including example file like following

>> (load-file "protocol-example.clj")

Or library can be tested by including

>> (load-file "protocol.clj")
